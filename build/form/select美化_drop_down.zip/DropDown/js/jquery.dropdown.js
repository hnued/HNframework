function createDropDown() {
    var source = $(".source");
    var options = $("option", source);
    var selected = source.find("option[selected]");

    source.after('<dl class="dropdown"></dl>');
    $(".dropdown").append('<dt><a href="#">' + selected.text() + '<span class="value">' + selected.val() + '</span></a></dt>');
    $(".dropdown").append('<dd><ul></ul></dd>');

    options.each(function() {
        $(".dropdown dd ul").append('<li><a href="#">' + $(this).text() + '<span class="value">' + $(this).val() + '</span></a></li>');
    });

    $(".dropdown dt a").click(function() {
        $(".dropdown dd ul").toggle();
        return false;
    });

    $(".dropdown dd ul li a").click(function() {
        $(".dropdown dt a").html($(this).html());
        $(".dropdown dd ul").hide();

        source.val($(this).find("span.value").html());
        return false;
    });

    $(document).bind('click',
    function(e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdown")) {
            $(".dropdown dd ul").hide();
        }
    });
}